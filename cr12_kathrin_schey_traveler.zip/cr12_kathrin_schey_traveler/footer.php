<!-- <div class="try">
<div id="demo" class="carousel slide" data-ride="carousel"> -->

  <!-- Indicators -->
  <!-- <ul class="carousel-indicators">
    <li data-target="#demo" data-slide-to="0" class="active"></li>
    <li data-target="#demo" data-slide-to="1"></li>
    <li data-target="#demo" data-slide-to="2"></li>
  </ul> -->

  <!-- The slideshow -->
  <!-- <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="img-fluid" src="https://images.pexels.com/photos/41004/alaska-wilderness-sky-aurora-borealis-41004.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500" alt="alaska">
    </div>
    <div class="carousel-item">
      <img class="img-fluid" src="https://images.pexels.com/photos/927485/pexels-photo-927485.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500" alt="hongkong">
    </div>
    <div class="carousel-item">
      <img class="img-fluid" src="https://images.pexels.com/photos/39003/scotland-united-kingdom-england-isle-of-skye-39003.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500" alt="schottland">
    </div>
    <div class="carousel-item">
      <img class="img-fluid" src="https://cdn.pixabay.com/photo/2016/08/11/23/48/italy-1587287__340.jpg" alt="italien">
    </div>
    <div class="carousel-item">
      <img class="img-fluid" src="https://media.istockphoto.com/photos/sheep-at-rock-of-cashel-ireland-picture-id1175289929?b=1&k=6&m=1175289929&s=170667a&w=0&h=FJan9bFZMoPK3fTa8FTzdZf7NKhQlEDKzzbjmWLvhEo=" alt="irland">
    </div>
    <div class="carousel-item">
      <img class="img-fluid" src="https://cdn.pixabay.com/photo/2017/01/16/19/54/ireland-1985088__340.jpg" alt="irland">
    </div>
    <div class="carousel-item">
      <img class="img-fluid" src="https://media.istockphoto.com/photos/swedish-coastal-huts-picture-id1145415400?b=1&k=6&m=1145415400&s=170667a&w=0&h=Gx02yyKIKx5CC9Hw4kQaPkFU9A7q_EZIpKsU6t3H5Cs=" alt="schweden">
    </div>
    <div class="carousel-item">
      <img class="img-fluid" src="https://media.istockphoto.com/photos/swedish-meatballs-in-a-pan-picture-id1142400254?b=1&k=6&m=1142400254&s=170667a&w=0&h=o7P3jmJs31lVsRu2l9vlq85K1zuSF3GFdzb4fmBxul4=" alt="schweden">
    </div>
  </div> -->
 	<!-- </div> -->

  <!-- Left and right controls -->
  <!-- <a class="carousel-control-prev" href="#demo" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#demo" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>

</div> -->
<footer class="d-flex justify-content-around mt-5">
	<div class="adress m-3 p-2">
		<p>SK-Travel Agency</p>
		<p>Zu-Hause-Strasse 7</p>
		<p>2574 Woauchimmer- Austria</p>		
		<p>T: +43 677 658 69 87 </p>
		<p>F: +43 123 456 87</p>
		<p>E: mounteverest@mail.com</p>		
	</div>
	<div class="container-icons m-3 p-2 d-flex justify-content-around">
		<div class="png">
			<a href="#" title="">
				<img class="img-fluid" src="https://img.icons8.com/clouds/2x/facebook-f.png">
			</a>
		</div>
		<div class="png">
			<a href="#" title="">
				<img class="img-fluid" src="https://img.icons8.com/cute-clipart/2x/instagram-new.png">
			</a>
		</div>
		<div class="png">
			<a href="#" title="">
				<img class="img-fluid" src="https://img.icons8.com/doodle/2x/linkedin.png">
			</a>
		</div>
		<div class="png">
			<a href="#" title="">
				<img class="img-fluid" src="https://img.icons8.com/doodle/2x/twitter.png">
			</a>
		</div>	
	</div> 
</footer>
<?php wp_footer(); ?>
<script
  src="https://code.jquery.com/jquery-3.5.0.min.js"
  integrity="sha256-xNzN2a4ltkB44Mc/Jz3pT4iU1cmeR0FkXs4pru/JxaQ="
  crossorigin="anonymous">  	
</script>

</body>

</html>