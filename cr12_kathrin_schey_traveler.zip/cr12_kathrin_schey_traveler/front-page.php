<?php get_header(); ?>

        <div class="container-fluid">                
                
                       <div class="home-header">
                        
                          <h1 text-center>Mount Everest</h1>
                          <!-- <img class="img-responsive" src="<?php get_template_directory_uri(); ?>/logo.png" alt="image"> -->
                                                
                         <p class="h3">We have all weeks Specials</p>
                         <p class="h3">First come, first save</p>
                         <p class="h3">Du willst nie wieder wo anders Buchen ;)</p>  
                       </div> 

                      <h2 class="mt-3 h1 text-center">Services</h2>

                      <div class="row justify-content-around">
                        <div class="col-lg-4 col-md-6 col-sm-12 text-center info">
                                <div class="pic my-5">
                                    <img class="img-fluid rounded-circle" src="https://static.wixstatic.com/media/93ea04e698dd4d998fcc0f5304425eda.jpg/v1/fill/w_288,h_288,al_c,q_80,usm_0.66_1.00_0.01/Aspiring%20Pilot.webp" alt="">    
                                </div>                	                    	      
                               <p>We offer the best deals on flights worldwide. Great prices, Multi-city Tickets. No hidden fees. Trusted travel experts for easy and fast booking. send us as email or call us to book your flight.</p>
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-12 text-center info">
                                <div class="pic my-5">
                                    <img class="img-fluid rounded-circle" src="https://static.wixstatic.com/media/3d0bad396e2041388553c427d5bd26fe.jpg/v1/fill/w_288,h_288,al_c,q_80,usm_0.66_1.00_0.01/Train%20Station.webp" alt="">    
                                </div>                	       
                               <p>Severl bus &  train companies that are comfortable and affordable to several european cities. Seat booking, Luggage included. Flixbus, Regiojet, ÖBB, DB, TGV, Intercity and much more</p>
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-12 text-center info">
                                <div class="pic my-5">
                                      <img class="img-fluid rounded-circle" src="https://static.wixstatic.com/media/b22e6dfb3664405480977771f4f12116.jpg/v1/fill/w_288,h_288,al_c,q_80,usm_0.66_1.00_0.01/Tour%20Bus.webp" alt="">  
                                </div>                	       
                               <p>Guided city tours with certified tourist guides, exclusive and private tours, or tours with groups in several cities in central europe including walking tours, hiop-on hop-off and other professional service carriers.</p>
                               
                         </div>
                </div>                
        </div>

<?php get_footer(); ?>